// ═══════════════════════════════════════════════════════════════
//  NovaTech BD — Input Validators
//  utils/validators.js
// ═══════════════════════════════════════════════════════════════

export const validators = {

  required: (v) => v !== null && v !== undefined && String(v).trim().length > 0
    ? null : 'This field is required.',

  email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
    ? null : 'Enter a valid email address.',

  phone: (v) => /^(?:\+88)?01[3-9]\d{8}$/.test((v || '').replace(/\s/g, ''))
    ? null : 'Enter a valid BD phone (e.g. 01XXXXXXXXX).',

  minLength: (min) => (v) => String(v || '').trim().length >= min
    ? null : `Minimum ${min} characters required.`,

  maxLength: (max) => (v) => String(v || '').trim().length <= max
    ? null : `Maximum ${max} characters allowed.`,

  positiveNumber: (v) => !isNaN(v) && Number(v) > 0
    ? null : 'Must be a positive number.',

  nonNegativeNumber: (v) => !isNaN(v) && Number(v) >= 0
    ? null : 'Must be zero or a positive number.',

  percentage: (v) => !isNaN(v) && Number(v) >= 0 && Number(v) <= 100
    ? null : 'Must be between 0 and 100.',

  url: (v) => !v || /^https?:\/\/.+\..+/.test(v)
    ? null : 'Enter a valid URL.',

  password: (v) => String(v || '').length >= 8
    ? null : 'Password must be at least 8 characters.',

  strongPassword: (v) => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(v)
    ? null : 'Password must include uppercase, lowercase, and a number.',

  match: (other) => (v) => v === other
    ? null : 'Values do not match.',

  fileSize: (maxMB) => (file) => !file || file.size <= maxMB * 1024 * 1024
    ? null : `File must be under ${maxMB}MB.`,

  fileType: (types) => (file) => !file || types.some(t => file.type.startsWith(t))
    ? null : `Allowed types: ${types.join(', ')}.`,
};

// ── Validate a whole form object ───────────────────────────────
// schema: { fieldName: [validatorFn, ...] }
// returns: { valid: bool, errors: { fieldName: 'msg' } }
export const validateForm = (data, schema) => {
  const errors = {};
  for (const [field, rules] of Object.entries(schema)) {
    for (const rule of rules) {
      const err = rule(data[field]);
      if (err) { errors[field] = err; break; }
    }
  }
  return { valid: Object.keys(errors).length === 0, errors };
};

// ── Show inline error on an input ─────────────────────────────
export const showFieldError = (inputId, msg) => {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.style.borderColor = msg ? '#ef4444' : '';
  let errEl = document.getElementById(inputId + '_err');
  if (msg) {
    if (!errEl) {
      errEl = document.createElement('span');
      errEl.id = inputId + '_err';
      errEl.style.cssText = 'color:#ef4444;font-size:11px;display:block;margin-top:3px;';
      input.parentNode.insertBefore(errEl, input.nextSibling);
    }
    errEl.textContent = msg;
  } else if (errEl) {
    errEl.remove();
  }
};

// ── Clear all field errors ─────────────────────────────────────
export const clearFormErrors = (formId) => {
  const form = document.getElementById(formId);
  if (!form) return;
  form.querySelectorAll('[id$="_err"]').forEach(el => el.remove());
  form.querySelectorAll('input,select,textarea').forEach(el => el.style.borderColor = '');
};

// ── Sanitize text input (XSS basic) ───────────────────────────
export const sanitize = (str) =>
  String(str || '').replace(/[<>'"]/g, c => ({'<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
