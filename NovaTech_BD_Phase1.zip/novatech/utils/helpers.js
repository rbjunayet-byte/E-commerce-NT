// ═══════════════════════════════════════════════════════════════
//  NovaTech BD — Utility Helpers
//  utils/helpers.js
// ═══════════════════════════════════════════════════════════════

import { APP } from '../firebase.config.js';

// ── Currency Formatting ────────────────────────────────────────
export const formatBDT = (amount) =>
  '৳ ' + Number(amount || 0).toLocaleString('en-BD', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

export const bn = (n) => formatBDT(n); // shorthand

// ── Date & Time ────────────────────────────────────────────────
export const today = () => new Date().toISOString().split('T')[0];

export const formatDate = (dateStr, locale = 'en-BD') =>
  dateStr ? new Date(dateStr).toLocaleDateString(locale, { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

export const formatDateTime = (ts) =>
  ts ? new Date(ts).toLocaleString('en-BD', { dateStyle: 'medium', timeStyle: 'short' }) : '—';

export const formatTime = (ts) =>
  ts ? new Date(ts).toLocaleTimeString('en-BD', { hour: '2-digit', minute: '2-digit' }) : '—';

export const currentMonth = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

export const isLate = (checkInTime, shiftStart = APP.defaultShift.start) => {
  if (!checkInTime) return false;
  const [sh, sm] = shiftStart.split(':').map(Number);
  const checkIn = new Date(checkInTime);
  const threshold = new Date(checkIn);
  threshold.setHours(sh, sm + APP.lateThresholdMinutes, 0, 0);
  return checkIn > threshold;
};

// ── String Helpers ─────────────────────────────────────────────
export const slugify = (str) =>
  str.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '').replace(/--+/g, '-');

export const truncate = (str, len = 60) =>
  str && str.length > len ? str.substring(0, len) + '…' : (str || '');

export const capitalize = (str) =>
  str ? str.charAt(0).toUpperCase() + str.slice(1).toLowerCase() : '';

export const initials = (name) =>
  name ? name.split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2) : '??';

// ── Number Helpers ─────────────────────────────────────────────
export const clamp = (val, min, max) => Math.min(Math.max(val, min), max);

export const pct = (value, total) =>
  total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';

export const roundTo = (num, decimals = 2) =>
  Math.round(num * 10 ** decimals) / 10 ** decimals;

// ── Order ID Generator ─────────────────────────────────────────
export const generateOrderId = () =>
  'NTB-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();

// ── OTP Generator ─────────────────────────────────────────────
export const generateOTP = () =>
  Math.floor(100000 + Math.random() * 900000).toString();

// ── Phone Validation (BD) ──────────────────────────────────────
export const isValidBDPhone = (phone) =>
  /^(?:\+88)?01[3-9]\d{8}$/.test(phone?.replace(/\s/g, ''));

// ── Color by Status ────────────────────────────────────────────
export const statusColor = (status) => ({
  pending:           '#f59e0b',
  confirmed:         '#3b82f6',
  processing:        '#8b5cf6',
  shipped:           '#06b6d4',
  out_for_delivery:  '#f97316',
  delivered:         '#10b981',
  cancelled:         '#ef4444',
  returned:          '#6b7280',
  refunded:          '#ec4899',
}[status] || '#6b7280');

export const statusLabel = (status) => ({
  pending:           'Pending',
  confirmed:         'Confirmed',
  processing:        'Processing',
  shipped:           'Shipped',
  out_for_delivery:  'Out for Delivery',
  delivered:         'Delivered',
  cancelled:         'Cancelled',
  returned:          'Returned',
  refunded:          'Refunded',
}[status] || status);

// ── LocalStorage with TTL ──────────────────────────────────────
export const cache = {
  set: (key, data, ttlMs = 5 * 60 * 1000) =>
    localStorage.setItem('ntb_' + key, JSON.stringify({ data, exp: Date.now() + ttlMs })),
  get: (key) => {
    try {
      const raw = localStorage.getItem('ntb_' + key);
      if (!raw) return null;
      const { data, exp } = JSON.parse(raw);
      if (Date.now() > exp) { localStorage.removeItem('ntb_' + key); return null; }
      return data;
    } catch { return null; }
  },
  del: (key) => localStorage.removeItem('ntb_' + key),
  clear: () => Object.keys(localStorage).filter(k => k.startsWith('ntb_')).forEach(k => localStorage.removeItem(k))
};

// ── Debounce ───────────────────────────────────────────────────
export const debounce = (fn, delay = 300) => {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
};

// ── DOM Shorthand ──────────────────────────────────────────────
export const $ = (id) => document.getElementById(id);
export const $$ = (sel) => document.querySelectorAll(sel);

// ── Show Toast ────────────────────────────────────────────────
export const showToast = (msg, isError = false, duration = 3000) => {
  const existing = document.getElementById('ntb-toast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.id = 'ntb-toast';
  el.style.cssText = `
    position:fixed; bottom:24px; left:50%; transform:translateX(-50%) translateY(100px);
    background:${isError ? '#ef4444' : '#10b981'}; color:#fff; padding:12px 24px;
    border-radius:50px; font-size:14px; font-weight:600; z-index:99999;
    box-shadow:0 8px 32px rgba(0,0,0,.25); transition:transform .3s cubic-bezier(.34,1.56,.64,1);
    max-width:90vw; text-align:center; white-space:nowrap;
  `;
  el.textContent = msg;
  document.body.appendChild(el);
  requestAnimationFrame(() => { el.style.transform = 'translateX(-50%) translateY(0)'; });
  setTimeout(() => {
    el.style.transform = 'translateX(-50%) translateY(100px)';
    setTimeout(() => el.remove(), 300);
  }, duration);
};

// ── Confirm Dialog ────────────────────────────────────────────
export const confirm = (msg) => window.confirm(msg);

// ── File → Base64 ─────────────────────────────────────────────
export const fileToBase64 = (file) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(r.result.split(',')[1]);
  r.onerror = rej;
  r.readAsDataURL(file);
});

// ── Commission Calculator ──────────────────────────────────────
export const getDefaultSlabs = () => [
  { min: 0,      max: 10000,  rate: 0   },
  { min: 10001,  max: 20000,  rate: 2   },
  { min: 20001,  max: 50000,  rate: 3   },
  { min: 50001,  max: 100000, rate: 4   },
  { min: 100001, max: Infinity, rate: 5 },
];

export const calcCommission = (saleAmount, slabs = getDefaultSlabs()) => {
  const slab = slabs.find(s => saleAmount >= s.min && saleAmount <= s.max);
  return slab ? Math.round(saleAmount * slab.rate / 100) : 0;
};
